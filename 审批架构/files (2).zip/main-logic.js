/**
 * 审批流程管理 - 主应用逻辑
 */

// 全局变量
let selectedProcessId = null;
let draggedRole = null;
let workflowNodes = [];
let processList = [];
let availableRoles = [];
let departmentData = { data: [] };
let isDraggingOver = false;

/**
 * 从JSON文件加载数据
 */
async function loadDataFromJson() {
    try {
        // 1. 加载审批架构.json文件（部门数据）
        try {
            const deptResponse = await fetch('审批架构.json');
            if (deptResponse.ok) {
                const deptData = await deptResponse.json();
                if (deptData.data && Array.isArray(deptData.data)) {
                    departmentData.data = deptData.data;
                    console.log(`✓ 成功加载 ${departmentData.data.length} 条部门数据`);
                }
            }
        } catch (e) {
            console.warn('⚠ 未找到审批架构.json，使用空数据');
        }
        
        // 2. 加载角色.json文件（角色和流程数据）
        try {
            const roleResponse = await fetch('角色.json');
            if (roleResponse.ok) {
                const roleData = await roleResponse.json();
                
                // 加载角色列表
                if (roleData.data && Array.isArray(roleData.data)) {
                    availableRoles = roleData.data.map(role => ({
                        id: role.SERIALCOLUMN,
                        name: role.RLNAME,
                        employeeCount: role.data1 ? role.data1.length : 0,
                        employees: role.data1 || []
                    }));
                    console.log(`✓ 成功加载 ${availableRoles.length} 个可用角色`);
                }
            } else {
                throw new Error('角色文件不存在');
            }
        } catch (e) {
            console.error('✗ 加载角色.json失败:', e.message);
            alert('无法加载角色数据文件 "角色.json"，请确保文件在同一目录下。');
        }
        
        // 3. 加载流程.json文件（流程列表）
        try {
            const processResponse = await fetch('流程.json');
            if (processResponse.ok) {
                const processData = await processResponse.json();
                if (processData.data && Array.isArray(processData.data)) {
                    processList = processData.data;
                    console.log(`✓ 成功加载 ${processList.length} 个审批流程`);
                }
            } else {
                // 如果没有流程文件，使用默认流程
                processList = getDefaultProcessList();
                console.log('⚠ 使用默认流程列表数据');
            }
        } catch (e) {
            console.warn('⚠ 未找到流程.json，使用默认数据');
            processList = getDefaultProcessList();
        }
        
        // 初始化员工权限编辑模块
        EmployeePermissionModal.init(departmentData);
        
        // 渲染页面
        renderProcessList();
        renderAvailableRoles();
        
        // 选中第一个流程
        if (processList.length > 0) {
            selectProcess(processList[0].id);
        }
        
        console.log('✓ 所有数据加载完成');
        
    } catch (error) {
        console.error('✗ 加载数据失败:', error);
        alert('数据加载失败: ' + error.message);
    }
}

/**
 * 获取默认流程列表
 */
function getDefaultProcessList() {
    return [
        {
            id: 'process1',
            name: '报销审批流程',
            amountLimit: 10000,
            createBy: 'ADMIN',
            updateTime: '2025-01-01 10:30:00',
            nodes: [
                { id: 'node1', role: '部门经理', employees: [] },
                { id: 'node2', role: '财务经理', employees: [] },
                { id: 'node3', role: '总经理', employees: [] }
            ]
        },
        {
            id: 'process2',
            name: '请假审批流程',
            amountLimit: null,
            createBy: 'ADMIN',
            updateTime: '2025-01-02 14:20:00',
            nodes: [
                { id: 'node1', role: '直属主管', employees: [] },
                { id: 'node2', role: '人事经理', employees: [] }
            ]
        },
        {
            id: 'process3',
            name: '采购审批流程',
            amountLimit: 50000,
            createBy: 'ADMIN',
            updateTime: '2025-01-03 09:15:00',
            nodes: [
                { id: 'node1', role: '采购经理', employees: [] },
                { id: 'node2', role: '财务经理', employees: [] },
                { id: 'node3', role: '总经理', employees: [] }
            ]
        }
    ];
}

// ============ 渲染函数 ============

/**
 * 渲染流程列表
 */
function renderProcessList() {
    const container = document.getElementById('processList');
    if (!container) return;
    
    container.innerHTML = processList.map(process => {
        const isActive = selectedProcessId === process.id;
        return `
            <div class="p-3 ${isActive ? 'bg-orange-50 border-l-4 border-orange-500' : 'bg-gray-50 border-l-4 border-transparent'} rounded cursor-pointer hover:bg-orange-50 transition"
                 onclick="selectProcess('${process.id}')">
                <div class="font-semibold ${isActive ? 'text-gray-900' : 'text-gray-700'}">${process.name}</div>
                
                ${process.amountLimit != null ? 
                    `<div class="text-xs text-orange-600 mt-1">
                        <i class="fas fa-coins mr-1"></i>≤ ¥${process.amountLimit.toLocaleString()}
                    </div>` : 
                    `<div class="text-xs text-gray-500 mt-1">
                        <i class="fas fa-infinity mr-1"></i>无金额限制
                    </div>`
                }
                
                <div class="text-xs text-gray-500 mt-1">
                    <i class="fas fa-user mr-1"></i>${process.createBy || 'N/A'}
                    <span class="ml-2">
                        <i class="fas fa-clock mr-1"></i>${process.updateTime || 'N/A'}
                    </span>
                </div>
                
                <div class="text-xs text-gray-400 mt-1">
                    ${process.nodes ? process.nodes.length : 0} 个节点
                </div>
            </div>
        `;
    }).join('');
}

/**
 * 选择流程
 */
function selectProcess(processId) {
    selectedProcessId = processId;
    const process = processList.find(p => p.id === processId);
    
    if (process) {
        // 加载该流程的节点配置
        workflowNodes = process.nodes || [];
        
        console.log(`📋 选择流程: ${process.name}，包含 ${workflowNodes.length} 个节点`);
        
        // 为每个节点加载员工信息（从角色数据中获取）
        workflowNodes.forEach((node, index) => {
            console.log(`\n处理节点 ${index + 1}:`, {
                id: node.id,
                role: node.role,
                roleId: node.roleId,
                roleName: node.roleName,
                当前员工数: node.employees ? node.employees.length : '无employees字段'
            });
            
            // 如果节点已经有完整的员工数据，保留它
            if (node.employees && node.employees.length > 0 && node.employees[0].name) {
                console.log(`  ℹ️ 节点已有 ${node.employees.length} 名员工，保留现有数据`);
                return;
            }
            
            // 初始化或重置员工数组
            node.employees = [];
            
            // 尝试通过roleId或role名称查找对应的角色
            let role = null;
            
            // 方式1：通过roleId查找
            if (node.roleId) {
                role = availableRoles.find(r => r.id === node.roleId);
                if (role) {
                    console.log(`  ✓ 通过roleId找到角色: ${role.name}`);
                }
            }
            
            // 方式2：通过role名称查找（如果roleId不存在或没找到）
            if (!role && node.role) {
                role = availableRoles.find(r => r.name === node.role);
                if (role) {
                    console.log(`  ✓ 通过role名称找到角色: ${role.name} (ID: ${role.id})`);
                    // 如果找到了角色，更新节点的roleId
                    node.roleId = role.id;
                }
            }
            
            // 方式3：通过roleName查找（兼容性）
            if (!role && node.roleName) {
                role = availableRoles.find(r => r.name === node.roleName);
                if (role) {
                    console.log(`  ✓ 通过roleName找到角色: ${role.name} (ID: ${role.id})`);
                    node.roleId = role.id;
                    node.role = node.roleName;
                }
            }
            
            // 如果找到角色且角色有员工，加载员工信息
            if (role) {
                if (role.employees && role.employees.length > 0) {
                    node.employees = role.employees.map(emp => ({
                        id: emp.SERIALCOLUMN,
                        userId: emp.RLUSER,
                        name: emp.RUSERNAME,
                        title: emp.RDDESC || node.role || node.roleName || '未知职位',
                        roleId: role.id
                    }));
                    console.log(`  ✅ 成功为节点 "${node.role || node.roleName}" 加载了 ${node.employees.length} 名员工`);
                    console.log(`     员工列表: ${node.employees.map(e => e.name).join(', ')}`);
                } else {
                    console.warn(`  ⚠️ 角色 "${role.name}" 没有员工数据 (data1为空)`);
                }
            } else {
                console.error(`  ❌ 未找到匹配的角色: "${node.role || node.roleName || node.roleId}"`);
                if (availableRoles.length > 0) {
                    console.log(`     可用角色列表: ${availableRoles.map(r => r.name).join(', ')}`);
                }
            }
        });
        
        console.log(`\n✓ 流程加载完成，开始渲染工作流\n`);
        renderWorkflow();
        renderProcessList(); // 更新列表高亮
    }
}

/**
 * 渲染可用角色列表
 */
function renderAvailableRoles() {
    const container = document.querySelector('#rolePanel .overflow-y-auto');
    if (!container) return;
    
    if (availableRoles.length === 0) {
        container.innerHTML = `
            <div class="text-center py-8 text-gray-500">
                <i class="fas fa-inbox text-4xl mb-2"></i>
                <p>暂无可用角色</p>
                <p class="text-xs mt-1">请检查角色.json文件</p>
            </div>
        `;
        return;
    }
    
    container.innerHTML = availableRoles.map(role => `
        <div class="role-card p-3 bg-gray-50 rounded-lg border border-gray-200 cursor-move hover:border-orange-300 hover:bg-orange-50 transition" 
             draggable="true"
             data-role-id="${role.id}"
             data-role-name="${role.name}">
            <div class="font-medium text-gray-900">${role.name}</div>
            <div class="text-xs text-gray-500 mt-1">
                <i class="fas fa-users mr-1"></i>${role.employeeCount} 名员工
            </div>
            <div class="text-xs text-gray-400 mt-1">拖拽到左侧添加节点</div>
        </div>
    `).join('');
    
    // 重新绑定拖拽事件
    bindRoleDragEvents();
}

/**
 * 绑定角色卡片的拖拽事件
 */
function bindRoleDragEvents() {
    document.querySelectorAll('.role-card').forEach(card => {
        const roleName = card.dataset.roleName;
        card.addEventListener('dragstart', (e) => handleRoleDragStart(e, roleName));
        card.addEventListener('dragend', handleRoleDragEnd);
    });
}

// ============ 拖拽功能 ============

/**
 * 角色卡片开始拖拽
 */
function handleRoleDragStart(e, roleName) {
    draggedRole = roleName;
    e.dataTransfer.effectAllowed = 'copy';
    e.dataTransfer.setData('text/plain', roleName);
    e.target.style.opacity = '0.5';
}

/**
 * 角色卡片拖拽结束
 */
function handleRoleDragEnd(e) {
    e.target.style.opacity = '1';
    draggedRole = null;
    isDraggingOver = false;
    // 移除所有拖拽指示器
    document.querySelectorAll('.drop-indicator.active').forEach(el => {
        el.classList.remove('active');
    });
}

/**
 * 画布拖拽进入
 */
function handleCanvasDragOver(e) {
    if (!draggedRole) return;
    e.preventDefault();
    e.stopPropagation();
    e.dataTransfer.dropEffect = 'copy';
}

/**
 * 画布放置
 */
function handleCanvasDrop(e) {
    e.preventDefault();
    e.stopPropagation();
    if (draggedRole) {
        addWorkflowNode(draggedRole);
        isDraggingOver = false;
    }
}

/**
 * 节点间拖拽进入
 */
function handleNodeDragOver(e, nodeId) {
    if (!draggedRole) return;
    e.preventDefault();
    e.stopPropagation();
    
    const dropzone = e.currentTarget.querySelector('.drop-indicator');
    if (dropzone && !dropzone.classList.contains('active')) {
        // 移除其他指示器
        document.querySelectorAll('.drop-indicator.active').forEach(el => {
            if (el !== dropzone) {
                el.classList.remove('active');
            }
        });
        dropzone.classList.add('active');
    }
}

/**
 * 节点间拖拽离开
 */
function handleNodeDragLeave(e, nodeId) {
    e.preventDefault();
    e.stopPropagation();
    
    // 检查是否真的离开了这个区域
    const rect = e.currentTarget.getBoundingClientRect();
    const x = e.clientX;
    const y = e.clientY;
    
    if (x < rect.left || x >= rect.right || y < rect.top || y >= rect.bottom) {
        const dropzone = e.currentTarget.querySelector('.drop-indicator');
        if (dropzone) {
            dropzone.classList.remove('active');
        }
    }
}

/**
 * 节点间放置
 */
function handleNodeDrop(e, nodeId) {
    e.preventDefault();
    e.stopPropagation();
    
    const dropzone = e.currentTarget.querySelector('.drop-indicator');
    if (dropzone) {
        dropzone.classList.remove('active');
    }
    
    if (draggedRole) {
        const nodeIndex = workflowNodes.findIndex(n => n.id === nodeId);
        if (nodeIndex !== -1) {
            // 插入到当前节点之前（上方）
            insertWorkflowNode(draggedRole, nodeIndex);
        }
        isDraggingOver = false;
    }
}

/**
 * 添加审批节点
 */
function addWorkflowNode(roleName) {
    // 从可用角色中查找该角色
    const role = availableRoles.find(r => r.name === roleName);
    
    const newNode = {
        id: `node${Date.now()}`,
        role: roleName,
        roleId: role ? role.id : null,
        roleName: roleName,
        employees: []
    };
    
    // 如果找到角色，自动添加该角色下的所有员工
    if (role && role.employees && role.employees.length > 0) {
        newNode.employees = role.employees.map(emp => ({
            id: emp.SERIALCOLUMN,
            userId: emp.RLUSER,
            name: emp.RUSERNAME,
            title: emp.RDDESC || roleName,
            roleId: role.id
        }));
        console.log(`✓ 自动添加 ${newNode.employees.length} 名员工到节点`);
    }
    
    workflowNodes.push(newNode);
    renderWorkflow();
}

/**
 * 在指定位置插入节点
 */
function insertWorkflowNode(roleName, index) {
    // 从可用角色中查找该角色
    const role = availableRoles.find(r => r.name === roleName);
    
    const newNode = {
        id: `node${Date.now()}`,
        role: roleName,
        roleId: role ? role.id : null,
        roleName: roleName,
        employees: []
    };
    
    // 如果找到角色，自动添加该角色下的所有员工
    if (role && role.employees && role.employees.length > 0) {
        newNode.employees = role.employees.map(emp => ({
            id: emp.SERIALCOLUMN,
            userId: emp.RLUSER,
            name: emp.RUSERNAME,
            title: emp.RDDESC || roleName,
            roleId: role.id
        }));
        console.log(`✓ 自动添加 ${newNode.employees.length} 名员工到节点`);
    }
    
    workflowNodes.splice(index, 0, newNode);
    renderWorkflow();
}

/**
 * 删除节点
 */
function deleteNode(nodeId) {
    if (confirm('确定删除此审批节点吗？')) {
        workflowNodes = workflowNodes.filter(n => n.id !== nodeId);
        renderWorkflow();
    }
}

/**
 * 渲染工作流
 */
function renderWorkflow() {
    const canvas = document.getElementById('workflowCanvas');
    
    let html = `
        <!-- 开始节点 -->
        <div class="flex flex-col items-center">
            <div class="bg-orange-50 border-2 border-orange-500 rounded-lg px-6 py-3 text-orange-600 font-semibold">
                开始
            </div>
            <div class="w-0.5 h-8 bg-gray-300"></div>
        </div>
    `;

    workflowNodes.forEach((node, index) => {
        const iconMap = {
            '部门经理': 'fa-user-tie',
            '财务经理': 'fa-user-shield',
            '总经理': 'fa-crown',
            '人事经理': 'fa-user-cog',
            '直属主管': 'fa-user-check'
        };
        
        const icon = iconMap[node.role] || 'fa-user';
        
        html += `
            <!-- 审批节点 ${index + 1} -->
            <div class="flex flex-col items-center node-dropzone" 
                 ondragover="handleNodeDragOver(event, '${node.id}')"
                 ondragleave="handleNodeDragLeave(event, '${node.id}')"
                 ondrop="handleNodeDrop(event, '${node.id}')">
                
                <!-- 拖放指示器 -->
                <div class="drop-indicator w-full max-w-md h-12 border-2 border-dashed border-gray-300 rounded-lg mb-2 hidden items-center justify-center text-gray-400 text-sm">
                    <i class="fas fa-plus mr-2"></i>拖放到此处插入节点
                </div>
                
                <div class="role-node w-full max-w-md bg-white rounded-lg border-2 border-gray-200 p-4 cursor-pointer relative group">
                    <!-- 删除按钮 -->
                    <button onclick="deleteNode('${node.id}')" 
                            class="absolute -top-2 -right-2 w-6 h-6 bg-red-500 text-white rounded-full opacity-0 group-hover:opacity-100 transition-opacity hover:bg-red-600 z-10">
                        <i class="fas fa-times text-xs"></i>
                    </button>
                    
                    <div class="flex items-center justify-between mb-3">
                        <div class="flex items-center gap-2">
                            <i class="fas ${icon} text-orange-500"></i>
                            <span class="font-semibold text-gray-900">${node.role}</span>
                        </div>
                        <span class="text-xs bg-gray-100 px-2 py-1 rounded">审批节点 ${index + 1}</span>
                    </div>
                    
                    <!-- 员工标签列表 -->
                    <div class="flex flex-wrap gap-2">
                        ${(node.employees || []).map(emp => {
                            // 处理title，如果太长则截断
                            const displayTitle = emp.title && emp.title.length > 20 
                                ? emp.title.substring(0, 20) + '...' 
                                : (emp.title || node.role);
                            
                            return `
                                <div class="employee-tag px-3 py-1.5 bg-white border border-gray-300 rounded-full text-sm flex items-center gap-2 cursor-pointer hover:bg-orange-50 hover:border-orange-300 transition"
                                     onclick="EmployeePermissionModal.open('${emp.name}', '${node.role}', '${emp.id}')"
                                     title="${emp.title || node.role}">
                                    <i class="fas fa-user text-gray-500 text-xs"></i>
                                    <span class="font-medium">${emp.name}</span>
                                    <span class="text-xs text-gray-400">${displayTitle}</span>
                                    <i class="fas fa-cog text-orange-500 text-xs"></i>
                                </div>
                            `;
                        }).join('')}
                        <button onclick="addEmployeeToNode('${node.id}')" 
                                class="px-3 py-1.5 border-2 border-dashed border-gray-300 rounded-full text-sm text-gray-500 hover:border-orange-300 hover:text-orange-500 transition">
                            <i class="fas fa-plus mr-1"></i>添加员工
                        </button>
                    </div>
                </div>
                <div class="w-0.5 h-8 bg-gray-300"></div>
            </div>
        `;
    });

    html += `
        <!-- 结束节点 -->
        <div class="flex flex-col items-center">
            <div class="bg-green-50 border-2 border-green-500 rounded-lg px-6 py-3 text-green-600 font-semibold">
                结束
            </div>
        </div>
    `;

    canvas.innerHTML = html;
}

/**
 * 添加员工到节点
 */
function addEmployeeToNode(nodeId) {
    const node = workflowNodes.find(n => n.id === nodeId);
    if (node) {
        const name = prompt('请输入员工姓名:');
        if (name) {
            const title = prompt('请输入员工职位:');
            const newEmployee = {
                id: `emp${Date.now()}`,
                name: name,
                title: title || node.role
            };
            node.employees.push(newEmployee);
            renderWorkflow();
        }
    }
}

/**
 * 保存工作流
 */
function saveWorkflow() {
    console.log('保存工作流:', workflowNodes);
    alert('审批流程已保存');
}

/**
 * 导出工作流
 */
function exportWorkflow() {
    const data = JSON.stringify(workflowNodes, null, 2);
    const blob = new Blob([data], {type: 'application/json'});
    const url = URL.createObjectURL(blob);
    const a = document.createElement('a');
    a.href = url;
    a.download = '审批流程.json';
    a.click();
    URL.revokeObjectURL(url);
}

// ============ 初始化 ============

// 页面加载完成后初始化
document.addEventListener('DOMContentLoaded', async function() {
    // 动态加载员工权限弹框HTML
    const modalContainer = document.getElementById('employeePermissionModal');
    if (modalContainer) {
        try {
            const response = await fetch('employee-permission-modal.html');
            if (response.ok) {
                modalContainer.innerHTML = await response.text();
                console.log('✓ 员工权限弹框HTML已加载');
            }
        } catch (e) {
            console.error('✗ 加载员工权限弹框HTML失败:', e);
        }
    }
    
    // 加载JSON数据
    await loadDataFromJson();
});

// 监听员工权限保存事件
document.addEventListener('employeePermissionSaved', function(e) {
    console.log('员工权限已保存:', e.detail);
    // 这里可以添加额外的处理逻辑，比如更新界面等
});
